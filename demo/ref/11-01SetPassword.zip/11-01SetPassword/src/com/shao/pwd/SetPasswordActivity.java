package com.shao.pwd;


import kankan.wheel.widget.StrericWheelAdapter;
import kankan.wheel.widget.OnWheelChangedListener;
import kankan.wheel.widget.OnWheelScrollListener;
import kankan.wheel.widget.WheelView;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnticipateOvershootInterpolator;
import android.widget.Button;
import android.widget.TextView;

public class SetPasswordActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.passw_layout);
        //我改的
        initWheel(R.id.passw_1,new String[]{"1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"});
        initWheel(R.id.passw_2,new String[]{"1号","2号","3号","4号","5号","6号","7号","8号","9号","10号","11号","12号","13号","14号","15号","16号",
        		"17号","18号","19号","20号","21号","22号","23号","24号","25号","26号","27号","28号","29号","30号"});
    	Button btn=(Button)findViewById(R.id.pwd_status);
    	btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.out.println(getWheelValue(R.id.passw_1));
				System.out.println(getWheelValue(R.id.passw_2));
			}
		});
    }
    
    private boolean wheelScrolled = false;
    
    
    /**
     * Updates entered PIN status
     * 
     */
    
    private String getWheelValue(int id) {
    	return getWheel(id).getCurrentItemValue();
    }
//取值的方法
    //getWheelValue(R.id.passw_1)
    //getWheelValue(R.id.passw_2)

    /**
     * Returns wheel by Id
     * @param id the wheel Id
     * @return the wheel with passed Id
     * 我添加的
     * 
     */
    private WheelView getWheel(int id) {
    	return (WheelView) findViewById(id);
    }
    
    private void initWheel(int id,String[] strContents) {
        WheelView wheel = getWheel(id);
        wheel.setAdapter(new StrericWheelAdapter(strContents));
        wheel.setCurrentItem(0);
        
        wheel.setCyclic(true);
        wheel.setInterpolator(new AnticipateOvershootInterpolator());
    }
}
